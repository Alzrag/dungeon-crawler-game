#pragma once

#include <cstddef>
#include <vulkan/vk_platform.h>
#include <vulkan/vulkan.h>
#include <vulkan/vulkan_core.h>
#define GLFW_INCLUDE_VULKAN
#include <GLFW/glfw3.h>
#include <array>
#include <glm/glm.hpp>

struct Vertex{ 
  glm::vec2 pos;
  glm::vec3 color;
  glm::vec2 texCoord;

  static VkVertexInputBindingDescription getBindingDescription(){
    VkVertexInputBindingDescription bindingDescription{};
    bindingDescription.binding=0;
    bindingDescription.stride=sizeof(Vertex);
    bindingDescription.inputRate=VK_VERTEX_INPUT_RATE_VERTEX;

    return bindingDescription;
  }

  static std::array<VkVertexInputAttributeDescription, 3> getAttributeDescriptions(){
    std::array<VkVertexInputAttributeDescription, 3> attributeDescriptions{};
    attributeDescriptions[0].binding=0;
    attributeDescriptions[0].location=0;
    attributeDescriptions[0].format=VK_FORMAT_R32G32_SFLOAT;
    attributeDescriptions[0].offset=offsetof(Vertex, pos);

    attributeDescriptions[1].binding=0;
    attributeDescriptions[1].location=1;
    attributeDescriptions[1].format=VK_FORMAT_R32G32B32_SFLOAT;
    attributeDescriptions[1].offset=offsetof(Vertex, color);

    attributeDescriptions[2].binding=0;
    attributeDescriptions[2].location=2;
    attributeDescriptions[2].format = VK_FORMAT_R32G32_SFLOAT; 
    attributeDescriptions[2].offset=offsetof(Vertex, texCoord);

    return attributeDescriptions;
  }
};


inline const std::vector<Vertex> verticies = {
  {{-0.5f, -0.5f}, {1.0f, 0.0f, 0.0f}, {0.0f, 0.0f}},  // top-left
  {{ 0.5f, -0.5f}, {0.0f, 1.0f, 0.0f}, {1.0f, 0.0f}},  // top-right
  {{ 0.5f,  0.5f}, {0.0f, 0.0f, 1.0f}, {1.0f, 1.0f}},  // bottom-right
  {{-0.5f,  0.5f}, {1.0f, 1.0f, 1.0f}, {0.0f, 1.0f}}   // bottom-left
};

inline const std::vector<uint16_t> indicies {
  0,1,2,2,3,0
};
