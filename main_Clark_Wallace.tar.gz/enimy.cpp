#include "enimy.h"
#include <random>

std::random_device rd;
std::mt19937 mt(rd());

enimy::enimy(std::vector<std::vector<char>>* mapIn, fixed object, Engine* game){
  app = game;
  level=1;
  health = (((level-1)*10)+20);
  damage = (((level-1)*10)+20);
  map = mapIn; 
  std::uniform_int_distribution<int> pos(1,map->size());
  position = {pos(mt), pos(mt), 1.0f};
  while (mapIn->at(position.x+1).at(position.y+1)!=' '){
    position = {pos(mt), pos(mt), 1.0f};
  }
}

void enimy::takeDamage(int amount){
  health=health+=amount;
}

void enimy::hurt(){
  app->playerHealth+=damage;
}

struct node {
  int x,y;
  float f,g,h;
  bool open;
  node* parrent=nullptr;
  bool closed=false;

  node(){
    x=0;
    y=0;
    f=0;
    g=0;
    h=0;
    open=false;
  }
  void set(int xI,int yI,float gI,float hI, node* p){
    x=xI;
    y=yI;
    g=gI;
    h=hI;
    f=g+h;
    open=true;
    parrent=p;
  }
};

float distance(float x1,float x2,float y1, float y2){
  return abs(x1-x2)+abs(y1-y2);
}

bool isValid(int x,int y, const std::vector<std::vector<char>>& Maze){
  if(y<0||y>=Maze.size()||x<0||x>=Maze[0].size()) return false;
  if(Maze[y][x]=='#') return false;
  return true;
}

std::vector<std::vector<char>> solveMaze(std::vector<std::vector<char>>& Maze){
  std::cout<<"started solve"<<std::endl;
  int rows = Maze.size();
  int cols=Maze[0].size();
  node* start=nullptr;
  node* end(nullptr);
  std::vector<std::vector<node>> grid(rows, std::vector<node>(cols));

  //build grid
  for (int y = 0; y<rows;y++){
    for (int x = 0;x<cols;x++){
      grid[y][x].y=y;
      grid[y][x].x=x;
      if (Maze[y][x]=='E') start=&grid[y][x];
      if (Maze[y][x]=='S') end=&grid[y][x];
    }
  }
  
  std::vector<node*> open;
  start->set(start->x,start->y,0,distance(start->x, end->x, start->y, end->y), nullptr);
  open.push_back(start);

  while(!open.empty()){
    int bestOp=0;
    for (int i=1;i<(int)open.size();i++){
      if(open[i]->f<open[bestOp]->f){
        bestOp=i;
      }
    }
    node* current = open[bestOp];

    if(current->x==end->x&&current->y==end->y){ 
      node* temp = current->parrent;
      while(temp!=nullptr&&Maze[temp->y][temp->x]!='E'){
        Maze[temp->y][temp->x]='P';
        temp=temp->parrent;
      }
      return Maze;
    }

    open.erase(open.begin()+bestOp);
    current->closed=true;
    if(Maze[current->y][current->x]!='E'&&Maze[current->y][current->x]!='S')Maze[current->y][current->x]='V';

    int dx[]={0,0,-1,1};
    int dy[]={-1,1,0,0};

    for (int i=0;i<4;i++){
      int nx=current->x+dx[i];
      int ny=current->y+dy[i];

      if (isValid(nx, ny, Maze)){
        node* neighbor =&grid[ny][nx]; 
        if (neighbor->closed){
          continue;
        }
        float g = current->g+1.0f;
        if(!neighbor->open||g<neighbor->g){
          neighbor->set(nx,ny,g,distance(nx, end->x, ny, end->y), current);
          bool allreadyOpened=false;
          for (node* n: open){
            if(n==neighbor){
              allreadyOpened=true;
              break;
            }
          }
          if(!allreadyOpened){
            open.push_back(neighbor);
            if(Maze[neighbor->y][neighbor->x]!='E'&&Maze[neighbor->y][neighbor->x]!='S')Maze[neighbor->y][neighbor->x]='N';
          }
        }
      }
    }
  }
  return Maze;
}


void enimy::move(){
  if (state == "wander"){
    glm::vec3 target;
    std::uniform_int_distribution<int> pos(1,map->size());
    glm::vec3 newPosition = {pos(mt), pos(mt), 1.0f};
    while (map->at(position.x+1).at(position.y+1)!=' '){
      newPosition = {pos(mt), pos(mt), 1.0f};
    }
    std::vector<std::vector<char>> tempMap=*map;
    tempMap.at(newPosition.x).at(newPosition.y)='E';

    std::vector<std::vector<char>> tempMap2 = solveMaze(tempMap);
  }
}

void stateTransition(){

}



